import * as FileSaver from 'file-saver'
import * as XLSX from 'xlsx'

// import * as XLSX from 'sheetjs-style'
const fileExtension = '.xlsx'

export const exportDataToExcel = (csvData, fileName) => {
  const ws = XLSX.utils.json_to_sheet(csvData)
  const wb = { Sheets: { data: ws }, SheetNames: ['data'] }
  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
  const data = new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
  })
  FileSaver.saveAs(data, fileName + fileExtension)
}

export const checkLoginToken = () => {
  const token = localStorage.getItem("token");
  return token ? token : null;
};
export const getProfileFromLS = () => {
  const result = localStorage.getItem('profile')
  return result ? JSON.parse(result) : null
}

export const getTripDetailId = (array, startPoint, endPoint) => {
  for (let i = 0; i < array.length; i++) {
    const trip = array[i];
    if (trip.pointStartDetails === startPoint && trip.pointEndDetails === endPoint) {
      return trip.id;
    }
  }
  return null; // Or you can throw an error if no match is found
}